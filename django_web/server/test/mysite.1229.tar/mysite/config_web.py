#coding=utf-8

CONSOLE_PATH = "/home/test/console/"
CONSOLE_WORK_PATH = CONSOLE_PATH + "scripts/"

PROJECT_NAME = "mysite"
APP_NAME = "blog"


TEMPLATES_PATH = "/home/test/webapp/" + PROJECT_NAME + "/templates"

IP_ADDR = '172.1.128.170'


